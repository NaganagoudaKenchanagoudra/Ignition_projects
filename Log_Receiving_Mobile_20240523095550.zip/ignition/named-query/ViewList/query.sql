select Log_ID, SAP_ID from  Receiving_Logid where  MESDispatch_UUID=:newValue1

/*select
L.[Log_ID], L.[SAP_ID],M.[UUID]
from [Dispatch_Logid] as L
join [MES_Dispatch] as M
on L.[MESDispatch_UUID] = M.[UUID]
where M.[UUID]='U001'*/
/*select L.[Log_ID], L.[SAP_ID]
  FROM [dbo].[Dispatch_Logid] as L
  Join [dbo].[MES_Dispatch] as M
  ON L.[MESDispatch_UUID] = M.[UUID]
  where M.[STO_PO] = 'STP00023X32'*/