---SELECT UUID as 'value', STO_PO as label FROM MES_Receiving where [Dispatch status] = 'Completed' and status is null
---
--SELECT UUID as value ,STO_PO as label FROM MES_Receiving


 select  d.STO_PO AS label , d.UUID as value
  from [CIMS].[dbo].[MES_Dispatch] d
  join [OMS-DATA].[JALLOG].[dbo].[MES_Receiving] r
  on d.UUID = r.UUID
  where d.[Status] = 'completed' and r.status is null