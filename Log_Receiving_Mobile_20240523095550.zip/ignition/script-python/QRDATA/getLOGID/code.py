def MString(data):
	data=str(data)
	data=data.replace(' ','')
	return str(data)
	

def LOGID(DATA):
	AA=DATA
	#	AA= DATA.replace('\n','')
	AB=AA.split(':')
	FDATA=[]
	for i in range(len(AB)):
		C= AB[i]
		D=C.split()
		FDATA.append(D[0])
	
	#QR2 Data
	DATA1=DATA.split('\n')
	#Stored QR Data from LogID
	LOGID=MString(FDATA[1])
	return str(LOGID)