def doGet(request, session):

	data=request['postData']
	
	RETURN=data
	
	return {'json': RETURN[""]}