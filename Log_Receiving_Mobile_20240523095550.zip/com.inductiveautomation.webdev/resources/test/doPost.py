def doPost(request, session):


	data=request['postData']
	a=data["row"]
	
	RETURN=a
	
	return {'json': RETURN}