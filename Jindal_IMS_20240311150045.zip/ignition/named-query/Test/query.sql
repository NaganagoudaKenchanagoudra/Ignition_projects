SELECT TOP (1000) [id]
      ,[firstName]
      ,[lastName]
      ,[email]
      ,[password]
      ,[phoneNumber]
      ,[profileUrl]
      ,[roleId]
 
      ,[isActive]
      ,[createdBy]
  
      ,[updatedBy]
   
      ,[isDeleted]
      ,[sysStartTime]
      ,[sysEndTime]
  FROM [CIMS].[dbo].[mes_user1]