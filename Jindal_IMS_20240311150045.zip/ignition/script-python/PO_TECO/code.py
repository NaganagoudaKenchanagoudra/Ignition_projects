def Update(PONO):
	# Update the API Order table
	q1=''' 
	     update [OUTBOUNDCIMS].[dbo].[APISAPOrders]
		 set [status]='TECO'
		 where prod_order=?'''
	system.db.runPrepUpdate(q1, [PONO], 'SAPOUTBOUND')	 
		
	# Delete Mes.order
	q2=''' delete FROM [CIMS].[dbo].[mes_orders]
	       where production_order=?'''
	system.db.runPrepUpdate(q2, [PONO], 'CIMS2')  
	
	# Delete Mes.Main 
	q3=''' delete  FROM [CIMS].[dbo].[mes_main]
	       where PO=?'''
	system.db.runPrepUpdate(q3, [PONO], 'CIMS2')    
	
	return 'TECO update completed'