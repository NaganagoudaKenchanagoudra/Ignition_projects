import time
# Material cancel based on the parameter
def deleteEntry(PONO,UID,OPRN):
	A=str(UID).replace('[','')
	A=str(A).replace(']','')
	mquery='''
				SELECT 
				      [uid],
				      [oprn]
				      ,trim([prod_order]) as prod_order
				      ,trim([material_code]) as material_code
				      ,trim([material_description]) as material_description
				      ,trim([material_selection]) as cims_material_selection
				      ,trim([batch]) as batch
				      ,[qty]
				      ,trim([qty_uom]) as qty_uom
				  FROM [CIMS].[dbo].[mes_MF&HF_operation]
				  where prod_order=? and oprn=? and uid in ('''+ str(A) +''')
				  order by [date_time] desc
				'''
	m1query='''
			SELECT
				  [uid]
				  ,trim([material_selection]) as sap_material_selection
				  ,trim([batch]) as sap_batch
			       ,trim([valuation_type]) as valuation_type
			      ,trim([storage_loc]) as storage_loc
			      ,[mov_type]
			  FROM [INBOUNDCIMS].[dbo].[goodmov]
			  where prod_order=? and oprn =? and mov_type is null and uid in ('''+ str(A) +''')
			  order by DATE_TIME desc
			'''
	args=[PONO,OPRN]		
	data1 = system.db.runPrepQuery(mquery, args, 'CIMS2')
	data1 = system.dataset.toPyDataSet(data1)
	data2 = system.db.runPrepQuery(m1query, args, 'CIMS_SAP_IN')
	data2 = system.dataset.toPyDataSet(data2)
	DATASET= (Material_Transfer.Get_PO_and_OPRN_wise_data.combineDatasets([data1,data2], 'uid'))
#	return DATASET
	# Send cancellation of all materials added at MF&HF table at SAP.GodMov using movement type code
	Material_Transfer.Get_PO_and_OPRN_wise_data.Material_cancellation_in_godmov(DATASET)
	# Delete the entry in MFHF table
	Material_Transfer.Material_cancel.delete_MFHF_based_UID(PONO,UID)	 
	
	
# Delete the entries in MF&HF table
def delete_MFHF_based_UID(PONO,UID):
	A=str(UID).replace('[','')
	A=str(A).replace(']','')
	query='''
			delete FROM [CIMS].[dbo].[mes_MF&HF_operation]
			  where prod_order=? and uid in ('''+ str(A) +''')
			'''   
	return system.db.runPrepUpdate(query, [PONO], 'CIMS2')	