# pass 2 pydata and common column name toget merged dataset 
def combineDatasets(dataList, commonCol):
    ''' Combine multiple datasets based on a common column
        dataList: list of datasets
        commonCol: column name common to all datasets        
    '''
    commonCol=str(commonCol)
    # Convert all datsets to BasicDataset, if needed
    for i, data in enumerate(dataList):
        if 'com.inductiveautomation.ignition.common.BasicDataset' not in str(type(data)):
            dataList[i] = system.dataset.toDataSet(data)
    
    # Create default value dictionary containing all column names
    # with None values
    blankValueDict = {}
    for data in dataList:
        colNames = list(data.getColumnNames())
        for col in colNames:
            if col != commonCol and col not in blankValueDict.keys():
                blankValueDict[col] = None

    # Process the data
    dataDict = {}
    for data in dataList:
        colNames = list(data.getColumnNames())
        for i in xrange(data.rowCount):
            commonColValue = data.getValueAt(i, commonCol)
            if commonColValue not in dataDict.keys():
                dataDict[commonColValue] = blankValueDict.copy()
            for col in colNames:
                if col != commonCol:
                    dataDict[commonColValue][col] = data.getValueAt(i, col)

    # Create combined dataset
    headers = [commonCol] + sorted(blankValueDict.keys())
    data = []
    for key in sorted(dataDict.keys()):
        newRow=[]
        newRow.append(key)
        for col in headers[1:]:
            newRow.append(dataDict[key][col])
        data.append(newRow)
    
    FDATA=system.dataset.toDataSet(headers, data)
    return system.dataset.toPyDataSet(FDATA)

# Collect the materials used at MF&HF and GoodMov table using PO and OPRN
def getMaterials_added(PONO,OPRN):
	mquery='''
			SELECT 
			      [uid],
			      [oprn]
			      ,trim([prod_order]) as prod_order
			      ,trim([material_code]) as material_code
			      ,trim([material_description]) as material_description
			      ,trim([material_selection]) as cims_material_selection
			      ,trim([batch]) as batch
			      ,[qty]
			      ,trim([qty_uom]) as qty_uom
			  FROM [CIMS].[dbo].[mes_MF&HF_operation]
			  where prod_order=? and oprn=?
			  order by [date_time] desc
			'''
	args=[PONO,OPRN]
#	A = [1650, 1648, 1649, 1647, 1646]	
	data1 = system.db.runPrepQuery(mquery, args, 'CIMS2')
	data1 = system.dataset.toPyDataSet(data1)
	# Get array with UID in list
	UID_Array = map(lambda row: row[0], data1)

	# Using the map function to convert numbers to strings
	A_String = list(map(str, UID_Array))	
	# Remove '[' and ']' in A_String
	A=str(A_String)
	A=A.replace('[','')
	A=A.replace(']','')
	m1query='''
			SELECT
				  [uid]
				  ,[DATE_TIME]
				  ,trim([material_selection]) as sap_material_selection
				  ,trim([batch]) as sap_batch
			       ,trim([valuation_type]) as valuation_type
			      ,trim([storage_loc]) as storage_loc
			      ,[mov_type]
			  FROM [INBOUNDCIMS].[dbo].[goodmov]
			  where prod_order=? and oprn =? and mov_type is null and uid in ('''+A+''')
			  order by DATE_TIME desc
			'''
	data2 = system.db.runPrepQuery(m1query, args, 'CIMS_SAP_IN')
	data2 = system.dataset.toPyDataSet(data2)
	return (Material_Transfer.Get_PO_and_OPRN_wise_data.combineDatasets([data1,data2], 'uid'))

# Function to update movement_type based on the material selection
def Mselec(Selection):
	selec=Selection.replace(' ','')
	if selec=='IN':
		return '262'
	elif selec=='OUT':
		return '532'		

#	Material Cancellation update in godmov table based on the move_type	
def Material_cancellation_in_godmov(dataset):
	D=dataset
	query='''
		INSERT INTO [dbo].[goodmov]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[batch]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc]
		           ,[flag]
		           ,[uid]
		           ,[mov_type])
		     VALUES
		           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,'KG',trim(?),trim(?),0,?,?)
			'''
	for i in range (len(D)):
		args=[D[i]['oprn'],D[i]['prod_order'],D[i]['material_code'],D[i]['material_description'],D[i]['sap_material_selection'],D[i]['sap_batch'],D[i]['qty'],D[i]['valuation_type'],D[i]['storage_loc'],D[i]['uid'],Mselec(D[i]['sap_material_selection'])]
		system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')		

#	Yeild deletion in InitialSc table
def Yeild_cancellation(dataset):
	D=dataset				
	query= '''
			INSERT INTO [dbo].[initialsc]
			           ([oprn]
			           ,[prod_order]
			           ,[yield]
			           ,[long_text]
			           ,[oprn_start_execution_date]
			           ,[oprn_start_execution_time]
			           ,[oprn_end_execution_date]
			           ,[oprn_end_execution_time]
			           ,[flag]
			           ,[uid]
			           ,[mov_type])
			     VALUES
			           (?
			           ,trim(?)
			           ,?
			           ,trim(?)
			           ,trim(?)
			           ,?
			           ,trim(?)
			           ,?
			           ,0
			           ,?
			           ,trim(?))
	    '''  
	for i in range(len(D)):
		args=[D[i]['oprn'],D[i]['prod_order'],D[i]['yield'],D[i]['long_text'],D[i]['oprn_start_execution_date'],D[i]['oprn_start_execution_time'],D[i]['oprn_end_execution_date'],D[i]['oprn_end_execution_time'],D[i]['uid'],'102']
		system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
		
# Add the listed materials(PO2) into the MF&HF and Godmov tables with diff unique ID
def add_materials_mfhf_godmov_withUID(dataset,PO2):
	D=dataset	
	query='''
			INSERT INTO [dbo].[mes_MF&HF_operation]
			           ([oprn]
			           ,[prod_order]
			           ,[material_code]
			           ,[material_description]
			           ,[material_selection]
			           ,[batch]
			           ,[qty]
			           ,[qty_uom]
			           ,[valuation_type]
			           ,[storage_loc]
			           ,[uid])
		     VALUES
		           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,'KG',trim(?),trim(?),?)	
			'''
	query1='''
			INSERT INTO [dbo].[goodmov]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[batch]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc]
		           ,[flag]
		           ,[uid])
		     VALUES
		           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,'KG',trim(?),trim(?),0,?)
			'''	
	for i in range(len(D)):
		UID=system.tag.read('[B_IMS]REST_API/UID_MaterialEntry').value
		UID=UID+1	
		args=[D[i]['oprn'],PO2,D[i]['material_code'],D[i]['material_description'],D[i]['cims_material_selection'],D[i]['batch'],D[i]['qty'],D[i]['valuation_type'],D[i]['storage_loc'],UID]
		args1=[D[i]['oprn'],PO2,D[i]['material_code'],D[i]['material_description'],D[i]['sap_material_selection'],D[i]['sap_batch'],D[i]['qty'],D[i]['valuation_type'],D[i]['storage_loc'],UID]			
		system.db.runPrepUpdate(query, args, 'CIMS2')
		system.db.runPrepUpdate(query1, args1, 'CIMS_SAP_IN')	
		system.tag.writeAsync('[B_IMS]REST_API/UID_MaterialEntry', UID)
		
# Insert new entries in Initial_sc table 
def add_Initialsc(dataset,PONO,PO2):
	D=dataset				
	query= '''
			INSERT INTO [dbo].[initialsc]
			           ([oprn]
			           ,[prod_order]
			           ,[yield]
			           ,[long_text]
			           ,[oprn_start_execution_date]
			           ,[oprn_start_execution_time]
			           ,[oprn_end_execution_date]
			           ,[oprn_end_execution_time]
			           ,[flag]
			           ,[uid])
			     VALUES
			           (?
			           ,trim(?)
			           ,?
			           ,trim(?)
			           ,trim(?)
			           ,?
			           ,trim(?)
			           ,?
			           ,0
			           ,?)
	    '''  
	for i in range(len(D)):
		UID=system.tag.read('[B_IMS]REST_API/UID_Operation').value
		UID=UID+1
		args=[D[i]['oprn'],PONO,D[i]['yield'],D[i]['long_text'],D[i]['oprn_start_execution_date'],D[i]['oprn_start_execution_time'],D[i]['oprn_end_execution_date'],D[i]['oprn_end_execution_time'],UID]
		system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
		# Update the Mes_operation table
		query1='''
				UPDATE [dbo].[mes_operation_status]
				   SET [uid] = ?
				      ,[prod_order] = ?			      
				 WHERE [oprn]= ? and [prod_order]=?
				'''
		args1=[UID,PONO,D[i]['oprn'],PO2]	
		system.db.runPrepUpdate(query1, args1,'CIMS2')	
		system.tag.writeAsync('[B_IMS]REST_API/UID_Operation', UID)		

# Delete the entries available in PO1 at MF&HF table using PO No 
def delete_MFHF_usingPO(PONO):
	query='''
			delete FROM [CIMS].[dbo].[mes_MF&HF_operation]
			  where prod_order=?
			'''   
	return system.db.runPrepUpdate(query, [PONO], 'CIMS2')	
	
# Get Yeild based on the entries in MES and SAP database
def get_yeild(PONO):
	mquery='''
			SELECT [uid]
			      ,[oprn]
			      ,[prod_order]      
			  FROM [CIMS].[dbo].[mes_operation_status]
			  where [prod_order]=? and oprn in (10,20)
			'''
	args=[PONO]
	#	A = [1650, 1648, 1649, 1647, 1646]	
	data1 = system.db.runPrepQuery(mquery, args, 'CIMS2')
	data1 = system.dataset.toPyDataSet(data1)
	# Get array with UID in list
	UID_Array = map(lambda row: row[0], data1)
	#print UID_Array
	# Using the map function to convert numbers to strings
	A_String = list(map(str, UID_Array))	
	# Remove '[' and ']' in A_String
	A=str(A_String)
	A=A.replace('[','')
	A=A.replace(']','')
	#print A
	m1query='''
			SELECT [oprn]
						      ,trim([prod_order]) as prod_order
						      ,[yield]
						      ,trim([long_text]) as long_text
						      ,trim([oprn_start_execution_date]) as oprn_start_execution_date
						      ,[oprn_start_execution_time]
						      ,trim([oprn_end_execution_date]) as oprn_end_execution_date
						      ,[oprn_end_execution_time]
						      ,[flag]
						      ,[uid]
						      ,[mov_type]
						  FROM [INBOUNDCIMS].[dbo].[initialsc]
						  where prod_order=? and oprn in (10,20) and uid in ('''+A+''') and mov_type is null
						  order by DATE_TIME
			'''
	data2 = system.db.runPrepQuery(m1query, args, 'CIMS_SAP_IN')	
	return data2	 	          	      	 	          	      
				          	      	 	          	      