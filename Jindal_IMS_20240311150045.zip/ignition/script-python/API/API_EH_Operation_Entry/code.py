# Function to POST data into SAP for 04 operation
def post_Endcutt(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG):
	template={
	    "row":
	{
	      "id": "",
	      "oprn": "",
	      "log_batch_no": "",
	      "prod_order": "",
	      "scrap": "",
	      "sfg_code": "",
	      "yield": "",
	      "qty_uom": "KG",
	      "homog_start_date": "",
	      "homo_start_time": "",
	      "homo_end_date": "",
	      "homo_end_time": "",
	      "flag": "",
	      "message_type": "",
	      "remarks": ""
	}
	}
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = "0040"		
	template["row"]["log_batch_no"] = LOGID
	template["row"]["prod_order"] = PONO
#	template["row"]["scrap"] = SCRAP
	template["row"]["sfg_code"] = str(SFG)
	template["row"]["yield"] = YIELD	
	template["row"]["flag"] = int(FLAG)
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	payload=str(jsonParams)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/LogEndHomogenizing/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL3_EH_ENtry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value
	try:
		postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=300000,readTimeout =300000,bypassCertValidation=True)
	except:
		temp={
		    "id": ID,
		    "message_type": "E",
		    "remarks": "No response from SAP",
		    "sap_batch_no": ""
		}
		postReturn=str(temp)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	print RESPONSE
	
	#ADD APILOG Table
#	# Check the Response data and Fainalize the status	
#	if 'Confirmation Done' in str(RESPONSE['remarks']):
#		STATUS='I'
#	else:
#	Check if the Empty response from SAP
	if RESPONSE is None:
		# regenrate the API call with new Unique ID
		API.API_EH_Operation_Entry.regenrate_API()
		# Delete the API transaction
		API.API_EH_Operation_Entry.update_temlog_table(int(ID))	
		# Record the log data in API Log
		STATUS="R"
		API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,"Collected empty response from SAP",jsonParams)				
				
	# Check error condition and !='SAP ID Already generated'
	elif 'SAP ID Already generated'!= RESPONSE['remarks'] and RESPONSE['message_type']=='E':
		# Maintain the Error at Elog table
		API.Error_EH.move_to_Elog(RESPONSE['remarks'],payload)	
		
		# Update the Entry in tempLogmov table
		API.API_EH_Operation_Entry.update_temlog_table(int(ID))					
		print 'Error at operation 40'
	
	else:	
	#	If valid response SAP 
		STATUS=RESPONSE['message_type']
		SAPID=RESPONSE['sap_batch_no']
		if len(SAPID)>12:
			SAPID="SAP_ID_NA "
		else:
			pass	
	#	Update the SAPID to CIMS table
		query='''
				UPDATE [dbo].[mes_endcut_homogenize_dispatch]
				   SET [sap_batch_no] = trim(?)
				 WHERE [log_batch_no] = ?
				'''	
		args=[SAPID,LOGID]		
		system.db.runPrepUpdate(query, args, 'CIMS2')
		API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,RESPONSE['remarks'],jsonParams)	
		
		# Update the Entry in tempLogmov table
		API.API_EH_Operation_Entry.update_temlog_table(int(ID))		
	
	# Unblock the API que	
	system.tag.write('[B_IMS]REST_API/Q3', False)
	# Update Empty NA PO No to Tag
	system.tag.write('[B_IMS]REST_API/POQ3','NA3')	
	
# Function to POST data into SAP for 05 operation
def post_Homogenization(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG,SD,ST,ED,ET):
	template={
	    "row":
	{
	      "id": "",
	      "oprn": "",
	      "log_batch_no": "",
	      "prod_order": "",
	      "scrap": "",
	      "sfg_code": "",
	      "yield": "",
	      "qty_uom": "KG",
	      "homog_start_date": "",
	      "homo_start_time": "",
	      "homo_end_date": "",
	      "homo_end_time": "",
	      "flag": "",
	      "message_type": "",
	      "remarks": ""
	}
	}
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = "0050"		
	template["row"]["log_batch_no"] = LOGID
	template["row"]["prod_order"] = PONO
#	template["row"]["scrap"] = SCRAP
	template["row"]["sfg_code"] = str(SFG)
	template["row"]["yield"] = YIELD	
	template["row"]["flag"] = int(FLAG)
	template["row"]["homog_start_date"] = SD
	template["row"]["homo_start_time"] = ST
	template["row"]["homo_end_date"] = ED
	template["row"]["homo_end_time"] = ET
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/LogEndHomogenizing/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL3_EH_ENtry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value		
	postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=300000,readTimeout =300000,bypassCertValidation=True)
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	#	Check if the Empty response from SAP
	if RESPONSE is None:
		# regenrate the API call with new Unique ID
		API.API_EH_Operation_Entry.regenrate_API()
		# Delete the API transaction
		API.API_EH_Operation_Entry.update_temlog_table(int(ID))	
		# Record the log data in API Log
		STATUS="R"
		API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,"Collected empty response from SAP",jsonParams)				
	
	else:					
		#ADD APILOG Table
		# Check the Response data and Fainalize the status	
		if 'Confirmation Done' in str(RESPONSE['remarks']):
			STATUS='I'
		else:
			STATUS='E'	
		API.API_EH_Operation_Entry.add_log_in_APILOG_table(str(LOGID),str(PONO),int(ID),int(OPRN),STATUS,RESPONSE['remarks'],jsonParams)	
		
		# Update the Entry in tempLogmov table
		API.API_EH_Operation_Entry.update_temlog_table(int(ID))	
	
	# Unblock the API que	
	system.tag.write('[B_IMS]REST_API/Q3', False)
	# Update Empty NA PO No to Tag
	system.tag.write('[B_IMS]REST_API/POQ3','NA')	
	
# Function to add REST API log in API_Log table (CIMS2 DB)
def add_log_in_APILOG_table(LOGID,PONO,UID,OPRN,STATUS,REMARKS,PAYLOAD):
	query='''
			INSERT INTO [dbo].[API_logs]
			           ([uid]
			           ,[oprn]
			           ,[pono]
			           ,[status]
			           ,[message]
			           ,[logno]
			           ,[payload])
			     VALUES
			           (?,?,TRIM(?),TRIM(?),TRIM(?),TRIM(?),TRIM(?))
			'''
	args=[int(UID),int(OPRN),str(PONO),str(STATUS),str(REMARKS),str(LOGID),str(PAYLOAD)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	
	
# Function to update the entry in templog table
def update_temlog_table(UID):
	query='''
			UPDATE [dbo].[templogmov]
			   SET [flag] = 2
			 WHERE [uid]=? 
			'''
	args=[int(UID)]
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')
	
# Check the tempLogmov table and start REST API POST call
def Check_que_tempLogmov():
	try:
		query='''
				SELECT TOP (1) 
						TRIM([prod_order]) AS [prod_order]
				      ,TRIM([log_batch_no]) AS [log_batch_no]
				      ,TRIM([sfg_code]) AS [sfg_code]
				      ,[scrap]
				      ,[yield]
				      ,[qty_uom]
				      ,TRIM([homog_start_date]) AS [homog_start_date]
				      ,[homog_start_time]
				      ,TRIM([homog_end_date]) AS [homog_end_date]
				      ,[homog_end_time]
				      ,[flag]
				      ,[oprn]
				      ,[uid]
				  FROM [INBOUNDCIMS].[dbo].[templogmov]
				  where flag = 0 or flag = 1
				'''				
		args=[] 
		Dataset=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
		if len(Dataset)>=1:
			# Block tag for holding API
			system.tag.write('[B_IMS]REST_API/Q3', True)		
			# Update PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ3',Dataset[0]['prod_order'])		
			#Check oprn and switch the function for REST POST call
			if(Dataset[0]['oprn'])==40:
				# call End Cutt POST method
				Y = Dataset[0]['yield']	
				Y = "{:.3f}".format(Y)	
				print Y
				API.API_EH_Operation_Entry.post_Endcutt(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Y,Dataset[0]['flag'])
#				API.API_EH_Operation_Entry.post_Endcutt(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Dataset[0]['yield'],Dataset[0]['flag'])
				print 'Operation 40'
				
			else:
				# Call Homogenization POST method
	#			API.API_EH_Operation_Entry.post_Homogenization(ID,OPRN,LOGID,PONO,SCRAP,SFG,YIELD,FLAG,SD,ST,ED,ET)
				Y = Dataset[0]['yield']	
				Y = "{:.3f}".format(Y)	
				ST=system.date.format(Dataset[0]['homog_start_time'],'hh:mm:ss')
				ET=system.date.format(Dataset[0]['homog_end_time'],'hh:mm:ss')
				API.API_EH_Operation_Entry.post_Homogenization(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Y,Dataset[0]['flag'],Dataset[0]['homog_start_date'],ST,Dataset[0]['homog_end_date'],ET)
#				API.API_EH_Operation_Entry.post_Homogenization(Dataset[0]['uid'],Dataset[0]['oprn'],Dataset[0]['log_batch_no'],Dataset[0]['prod_order'],Dataset[0]['scrap'],Dataset[0]['sfg_code'],Dataset[0]['yield'],Dataset[0]['flag'],Dataset[0]['homog_start_date'],ST,Dataset[0]['homog_end_date'],ET)
				print 'Operation 50'
		else:
			print 'EMPTY'
			# Unblock API			
			system.tag.write('[B_IMS]REST_API/Q3', False)
			# Update Empty NA PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ3','NA3')	
	except:
		system.tag.write('[B_IMS]REST_API/Q3', False)
		# Update Empty NA PO No to Tag
		system.tag.write('[B_IMS]REST_API/POQ3','NA3')		
	
def regenrate_API():
	# get existing templog from db table
	query='''
			SELECT TOP (1) trim([prod_order]) as prod_order
			      ,trim([log_batch_no]) as log_batch_no
			      ,trim([sfg_code]) as sfg_code
			      ,[scrap]
			      ,[yield]
			      ,trim([qty_uom]) as qty_uom
			      ,trim([homog_start_date]) as homog_start_date
			      ,[homog_start_time]
			      ,trim([homog_end_date]) as homog_end_date
			      ,[homog_end_time]
			      ,[flag]
			      ,[oprn]
			      ,[uid]
			  FROM [INBOUNDCIMS].[dbo].[templogmov]
			'''
	Data=system.db.runPrepQuery(query, [], 'CIMS_SAP_IN')
	prod_order_1=Data[0]['prod_order']
	log_batch_no_1=Data[0]['log_batch_no']
	sfg_code_1=Data[0]['sfg_code']
	scrap_1=Data[0]['scrap']
	yield_1=Data[0]['yield']
	qty_uom_1=Data[0]['qty_uom']
	homog_start_date_1=Data[0]['homog_start_date']
	homog_start_time_1=Data[0]['homog_start_time']
	homog_end_date_1=Data[0]['homog_end_date']
	homog_end_time_1=Data[0]['homog_end_time']
	flag_1=Data[0]['flag']
	oprn_1=Data[0]['oprn']
	# Get current UID and Increment	
	uid_1=system.tag.readAsync('[B_IMS]REST_API/UID_Oper45').value
	uid_1=uid_1+1
	system.tag.write('[B_IMS]REST_API/UID_Oper45', uid_1)
	# Insert into logmovtable with new uid_1
	query2='''
			INSERT INTO [dbo].[logmov]
			           ([prod_order]
			           ,[log_batch_no]
			           ,[sfg_code]
			           ,[scrap]
			           ,[yield]
			           ,[qty_uom]
			           ,[homog_start_date]
			           ,[homog_start_time]
			           ,[homog_end_date]
			           ,[homog_end_time]
			           ,[flag]
			           ,[oprn]
			           ,[uid])
			     VALUES
			           (?,?,?,?,?,?,?,?,?,?,?,?,?)
			'''
	args=[prod_order_1,log_batch_no_1,sfg_code_1,scrap_1,yield_1,qty_uom_1,homog_start_date_1,homog_start_time_1,homog_end_date_1,homog_end_time_1,flag_1,oprn_1,uid_1]		
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')																								
