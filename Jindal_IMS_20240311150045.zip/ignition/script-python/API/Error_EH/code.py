def move_to_Elog(msg,payload):
	# get existing templog from db table
	query='''
			SELECT TOP (1) trim([prod_order]) as prod_order
			      ,trim([log_batch_no]) as log_batch_no
			      ,trim([sfg_code]) as sfg_code
			      ,[scrap]
			      ,[yield]
			      ,trim([qty_uom]) as qty_uom
			      ,trim([homog_start_date]) as homog_start_date
			      ,[homog_start_time]
			      ,trim([homog_end_date]) as homog_end_date
			      ,[homog_end_time]
			      ,[flag]
			      ,[oprn]
			      ,[uid]
			  FROM [INBOUNDCIMS].[dbo].[templogmov]
			'''
	Data=system.db.runPrepQuery(query, [], 'CIMS_SAP_IN')
	prod_order_1=Data[0]['prod_order']
	log_batch_no_1=Data[0]['log_batch_no']
	sfg_code_1=Data[0]['sfg_code']
	scrap_1=Data[0]['scrap']
	yield_1=Data[0]['yield']
	qty_uom_1=Data[0]['qty_uom']
	homog_start_date_1=Data[0]['homog_start_date']
	homog_start_time_1=Data[0]['homog_start_time']
	homog_end_date_1=Data[0]['homog_end_date']
	homog_end_time_1=Data[0]['homog_end_time']
	flag_1=Data[0]['flag']
	oprn_1=Data[0]['oprn']
	o_uid=Data[0]['uid']
	# Get current UID and Increment	
	uid_1=system.tag.read('[B_IMS]REST_API/UID_Oper45').value
	uid_1=uid_1+1
	system.tag.write('[B_IMS]REST_API/UID_Oper45', uid_1)
	MSG=msg
	P=str(payload)
	# Insert into Elogmovtable with new uid_1
	query2='''
			INSERT INTO [dbo].[Elogmov]
			           ([prod_order]
			           ,[log_batch_no]
			           ,[sfg_code]
			           ,[scrap]
			           ,[yield]
			           ,[qty_uom]
			           ,[homog_start_date]
			           ,[homog_start_time]
			           ,[homog_end_date]
			           ,[homog_end_time]
			           ,[flag]
			           ,[oprn]
			           ,[uid]
			           ,[msg]
			           ,[o_uid]
			           ,[payload])
			     VALUES
			           (?,?,?,?,?,?,?,?,?,?,?,?,?,trim(?),?,trim(?))
			'''
	args=[prod_order_1,log_batch_no_1,sfg_code_1,scrap_1,yield_1,qty_uom_1,homog_start_date_1,homog_start_time_1,homog_end_date_1,homog_end_time_1,0,oprn_1,uid_1,MSG,o_uid,P]		
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')	
	
	
def Resend_E_API(uid):
	# Collect data from Elog table	
	query='''
			SELECT trim([prod_order]) as prod_order
			      ,trim([log_batch_no]) as log_batch_no
			      ,trim([sfg_code]) as sfg_code
			      ,[scrap]
			      ,[yield]
			      ,trim([qty_uom]) as qty_uom
			      ,trim([homog_start_date]) as homog_start_date
			      ,[homog_start_time]
			      ,trim([homog_end_date]) as homog_end_date
			      ,[homog_end_time]
			      ,[flag]
			      ,[oprn]
			      ,[uid]
			  FROM [INBOUNDCIMS].[dbo].[Elogmov]
			  where uid=?
			'''
	Data=system.db.runPrepQuery(query, [uid], 'CIMS_SAP_IN')
	prod_order_1=Data[0]['prod_order']
	log_batch_no_1=Data[0]['log_batch_no']
	sfg_code_1=Data[0]['sfg_code']
	scrap_1=Data[0]['scrap']
	yield_1=Data[0]['yield']
	qty_uom_1=Data[0]['qty_uom']
	homog_start_date_1=Data[0]['homog_start_date']
	homog_start_time_1=Data[0]['homog_start_time']
	homog_end_date_1=Data[0]['homog_end_date']
	homog_end_time_1=Data[0]['homog_end_time']
	flag_1=Data[0]['flag']
	oprn_1=Data[0]['oprn']	
	uid_1=Data[0]['uid']
	
	#Update the entry in Elog table using UID
	q1='''update [INBOUNDCIMS].[dbo].[Elogmov]
			set flag=2
			where uid=?'''
	a1=[uid_1]
	system.db.runPrepUpdate(q1, a1, 'CIMS_SAP_IN')		
	
	# Insert new entry in logmov table
	query2='''
			INSERT INTO [dbo].[logmov]
			           ([prod_order]
			           ,[log_batch_no]
			           ,[sfg_code]
			           ,[scrap]
			           ,[yield]
			           ,[qty_uom]
			           ,[homog_start_date]
			           ,[homog_start_time]
			           ,[homog_end_date]
			           ,[homog_end_time]
			           ,[flag]
			           ,[oprn]
			           ,[uid])
			     VALUES
			           (?,?,?,?,?,?,?,?,?,?,?,?,?)
			'''
	args=[prod_order_1,log_batch_no_1,sfg_code_1,scrap_1,yield_1,qty_uom_1,homog_start_date_1,homog_start_time_1,homog_end_date_1,homog_end_time_1,0,oprn_1,uid_1]		
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')	
	
	
																			