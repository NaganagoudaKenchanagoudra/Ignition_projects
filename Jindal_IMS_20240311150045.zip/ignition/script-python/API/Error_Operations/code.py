def move_to_Elog(msg,payload):
	# get existing templog from db table
	query='''
			SELECT TOP (1) [oprn]
			      ,trim([prod_order]) as prod_order
			      ,[yield]
			      ,trim([long_text]) as long_text
			      ,trim([oprn_start_execution_date]) as oprn_start_execution_date
			      ,[oprn_start_execution_time]
			      ,trim([oprn_end_execution_date]) as oprn_end_execution_date
			      ,[oprn_end_execution_time]
			      ,[flag]
			      ,[uid]
			      ,trim([mov_type]) as mov_type  
			  FROM [INBOUNDCIMS].[dbo].[tempinitialsc]
			'''
	Data=system.db.runPrepQuery(query, [], 'CIMS_SAP_IN')
	oprn_1=Data[0]['oprn']
	prod_order_1=Data[0]['prod_order']
	yield_1=Data[0]['yield']
	long_text_1=Data[0]['long_text']
#	material_selection_1=Data[0]['material_selection']
	oprn_start_execution_date_1=Data[0]['oprn_start_execution_date']
	oprn_start_execution_time_1=Data[0]['oprn_start_execution_time']
	oprn_end_execution_date_1=Data[0]['oprn_end_execution_date']
	oprn_end_execution_time_1=Data[0]['oprn_end_execution_time']
	flag_1=Data[0]['flag']
	mov_type_1=Data[0]['mov_type']
	o_uid=Data[0]['uid']
	P=str(payload)
	# Condition to see Cancellation type	
	if 	mov_type_1 is None:
		# Get new Unique ID from tag
		uid_1=system.tag.read('[B_IMS]REST_API/UID_Operation').value
		uid_1=uid_1+1
		system.tag.write('[B_IMS]REST_API/UID_Operation', uid_1)
	else:
		# Use the same unique ID for cancelling the Operation
		uid_1=Data[0]['uid']	
	# Insert into Elogmovtable with new uid_1
	query2='''
			INSERT INTO [dbo].[Einitialsc]
			           ([oprn]
			           ,[prod_order]
			           ,[yield]
			           ,[long_text]
			           ,[oprn_start_execution_date]
			           ,[oprn_start_execution_time]
			           ,[oprn_end_execution_date]
			           ,[oprn_end_execution_time]
			           ,[uid]
			           ,[mov_type]
			           ,[msg]
			           ,[o_uid]
			           ,[payload])
			     VALUES
			           (?,trim(?),?,trim(?),trim(?),?,trim(?),?,?,trim(?),trim(?),?,trim(?))
			'''
			
	args=[oprn_1,prod_order_1,yield_1,long_text_1,oprn_start_execution_date_1,oprn_start_execution_time_1,oprn_end_execution_date_1,oprn_end_execution_time_1,uid_1,mov_type_1,msg,o_uid,P]		
	print 'Updated at Error log table'
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')	
	
	
def Resend_E_API(uid):
	# Collect data from Elog table	
	query='''
			SELECT [oprn]
			      ,trim([prod_order]) as prod_order
			      ,[yield]
			      ,trim([long_text]) as long_text
			      ,trim([oprn_start_execution_date]) as oprn_start_execution_date
			      ,[oprn_start_execution_time]
			      ,trim([oprn_end_execution_date]) as oprn_end_execution_date
			      ,[oprn_end_execution_time]
			      ,[flag]
			      ,[uid]
			      ,trim([mov_type]) as mov_type  
			  FROM [INBOUNDCIMS].[dbo].[Einitialsc]
			  where uid=?
			'''
	Data=system.db.runPrepQuery(query, [uid], 'CIMS_SAP_IN')
	oprn_1=Data[0]['oprn']
	prod_order_1=Data[0]['prod_order']
	yield_1=Data[0]['yield']
	long_text_1=Data[0]['long_text']
	oprn_start_execution_date_1=Data[0]['oprn_start_execution_date']
	oprn_start_execution_time_1=Data[0]['oprn_start_execution_time']
	oprn_end_execution_date_1=Data[0]['oprn_end_execution_date']
	oprn_end_execution_time_1=Data[0]['oprn_end_execution_time']
	flag_1=Data[0]['flag']
	mov_type_1=Data[0]['mov_type']
	uid_1=uid
	
	#Update the entry in Elog table using UID
	q1='''update [INBOUNDCIMS].[dbo].[Einitialsc]
			set flag=1
			where uid=?'''
	a1=[uid_1]
	system.db.runPrepUpdate(q1, a1, 'CIMS_SAP_IN')		
	
	# Insert new entry in initialsc table
	query2='''
			INSERT INTO [dbo].[initialsc]
			           ([oprn]
			           ,[prod_order]
			           ,[yield]
			           ,[long_text]
			           ,[oprn_start_execution_date]
			           ,[oprn_start_execution_time]
			           ,[oprn_end_execution_date]
			           ,[oprn_end_execution_time]
			           ,[uid]
			           ,[mov_type])
			     VALUES
			           (?,trim(?),?,trim(?),trim(?),?,trim(?),?,?,trim(?))
			'''
			
	args=[oprn_1,prod_order_1,yield_1,long_text_1,oprn_start_execution_date_1,oprn_start_execution_time_1,oprn_end_execution_date_1,oprn_end_execution_time_1,uid_1,mov_type_1]		
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')		
	
	
																			