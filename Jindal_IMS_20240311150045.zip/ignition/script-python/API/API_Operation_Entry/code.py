# Function to Post when operation completed
def post_SAP_IN(ID,OPRN,PONO,YIELD,TXT,SD,ST,ED,ET,F,MT):	
	template={
		  "row":
			{
			      "id": "",
			      "oprn": "",
			      "prod_order": "",
			      "yield": "",
			      "long_text": "",
			      "oprn_start_execution_date": "",
			      "oprn_start_execution_time": "",
			      "oprn_end_execution_date": "",
			      "oprn_end_execution_time": "",
			      "flag": "",
			      "message_type": "",
			      "remarks": "",
			      "mov_type":""
			}
			}				
	#if Yield in negitive value say as 0
	if 	float(YIELD)<=0:
		YIELD=0
	else:
		YIELD=YIELD		
	Y = YIELD
	Y = "{:.3f}".format(Y)				
	# Update the values of specific keys as needed
	template["row"]["id"] = int(ID)
	template["row"]["oprn"] = int(OPRN)		
	template["row"]["prod_order"] = PONO
	template["row"]["yield"] = Y
	template["row"]["long_text"] = TXT
	template["row"]["oprn_start_execution_date"] = str(SD)
	template["row"]["oprn_start_execution_time"] = ST
	template["row"]["oprn_end_execution_date"] = str(ED)
	template["row"]["oprn_end_execution_time"] = ET		
	template["row"]["flag"] = int(F)
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	payload=str(jsonParams)
	print jsonParams
	# post to SAP
	#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementHeader/'template = {
  	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL2_OperationEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value
	try:
		postReturn = system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=300000,readTimeout =300000,bypassCertValidation=True)
	except:	
		postReturn={
		    "id": ID,
		    "message_type": "E",
		    "remarks": "No response from SAP"
		}
	#Convert received data to dictonary
	print postReturn
	RESPONSE=system.util.jsonDecode(postReturn)
#	return jsonParams

#	if Response contains "" say status as Error
#	Check if the Empty response from SAP
	if len(str(RESPONSE))==2 or RESPONSE is None:
		# regenrate the API call with new Unique ID
		API.API_Operation_Entry.regenerate_API()
		# Delete the API transaction
		API.API_Operation_Entry.update_temInitialSc_table(int(ID))
		# Record the log data in API Log
		STATUS="R"
		API.API_Operation_Entry.update_log_table(int(ID),OPRN,PONO,STATUS,"Collected empty response from SAP",jsonParams)													
		
#		STATUS='E'
#		#Update the logtable
#		API.API_Operation_Entry.update_log_table(int(ID),OPRN,PONO,STATUS,"DATA NA",jsonParams)												 
#		#Update the tempgodmov table
#		API.API_Operation_Entry.update_temInitialSc_table(int(ID))
			
	else:	
		# Condition to save and acknowledge	
		if MT is not None and 'Document Cancelled' in str(RESPONSE['remarks']):
			STATUS='I'
			
		elif 'Confirmation Done' in str(RESPONSE['remarks']):
			STATUS='I'
		else:
			STATUS='E'	
			# Maintain the Error at EInitial_sc table with new UID
			API.Error_Operations.move_to_Elog(RESPONSE['remarks'],payload)	
			print 'ERROR'
		
		#Update the logtable
		API.API_Operation_Entry.update_log_table(ID,OPRN,PONO,STATUS,RESPONSE['remarks'],jsonParams)
		print 'Updated at API_LOG Table'											 
		#Update the tempInitialsc table
		API.API_Operation_Entry.update_temInitialSc_table(ID)
		print 'Updated TempInitialsc'	

	# Unblock the API que	
	system.tag.write('[B_IMS]REST_API/Q2', False)
	# Update NA PO No to Tag
	system.tag.write('[B_IMS]REST_API/POQ2','NA2')	
	
#	Function to update API log table	
def update_log_table(ID,OPRN,PONO,STATUS,REMARKS,PAYLOAD):
	query='''
				INSERT INTO [dbo].[API_logs]
				           ([uid]
				           ,[oprn]
				           ,[pono]
				           ,[status]
				           ,[message]
				           ,[payload])
				     VALUES
				           (?,?,?,?,?,?)
				'''
	args=[int(ID),int(OPRN),str(PONO),str(STATUS),str(REMARKS),str(PAYLOAD)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	
		
# Function to update the tempInitial_sc table
def update_temInitialSc_table(ID):
	query='''
			UPDATE [dbo].[tempinitialsc]
			   SET [flag] = 1
			 WHERE [uid]=?
				'''
	args=[int(ID)]
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')	
	
# Check the tempInitialSC table and call the function POST method to SAP
def temp_InitialSC_que_check():
	try:
		query='''
				SELECT TOP (1) [oprn]
				      ,trim([prod_order]) as [prod_order]
				      ,[yield]
				      ,trim([long_text]) as [long_text]
				      ,trim([oprn_start_execution_date]) as [oprn_start_execution_date]
				      ,[oprn_start_execution_time]
				      ,trim([oprn_end_execution_date]) as [oprn_end_execution_date]
				      ,[oprn_end_execution_time]
				      ,[flag]
				      ,[uid]
				      ,[mov_type]
				  FROM [INBOUNDCIMS].[dbo].[tempinitialsc]
				  where flag=0
			  '''	
		args=[]
		DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
		Y = DATASET[0]['yield']	
		Y = "{:.3f}".format(Y)	
		if len(DATASET)>=1:
			# Block tag for holding API
			system.tag.write('[B_IMS]REST_API/Q2', True)	
			# Update PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ2',DATASET[0]['prod_order'])		
			# Call the POST function 
			ST=system.date.format(DATASET[0]['oprn_start_execution_time'],'hh:mm:ss')
			ET=system.date.format(DATASET[0]['oprn_end_execution_time'],'hh:mm:ss')
			return API.API_Operation_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['yield'],DATASET[0]['long_text'],DATASET[0]['oprn_start_execution_date'],ST,DATASET[0]['oprn_end_execution_date'],ET,DATASET[0]['flag'],DATASET[0]['mov_type'])
#			return API.API_Operation_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],Y,DATASET[0]['long_text'],DATASET[0]['oprn_start_execution_date'],ST,DATASET[0]['oprn_end_execution_date'],ET,DATASET[0]['flag'],DATASET[0]['mov_type'])
		else:		
			# Unblock API		
			system.tag.write('[B_IMS]REST_API/Q2', False)
			# Update NA PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ2','NA2')	
			return 'Empty'	
			
	except:
		# Unblock API		
		system.tag.write('[B_IMS]REST_API/Q2', False)	
		# Update NA PO No to Tag
		system.tag.write('[B_IMS]REST_API/POQ2','NA2')	
				
		
# Regenrate API with new Unique ID
def regenerate_API():
	# get existing templog from db table
	query='''
			SELECT TOP (1) [oprn]
			      ,trim([prod_order]) as prod_order
			      ,[yield]
			      ,trim([long_text]) as long_text
			      ,trim([oprn_start_execution_date]) as oprn_start_execution_date
			      ,[oprn_start_execution_time]
			      ,trim([oprn_end_execution_date]) as oprn_end_execution_date
			      ,[oprn_end_execution_time]
			      ,[flag]
			      ,[uid]
			      ,trim([mov_type]) as mov_type  
			  FROM [INBOUNDCIMS].[dbo].[tempinitialsc]
			'''
	Data=system.db.runPrepQuery(query, [], 'CIMS_SAP_IN')
	oprn_1=Data[0]['oprn']
	prod_order_1=Data[0]['prod_order']
	yield_1=Data[0]['yield']
	long_text_1=Data[0]['long_text']
	material_selection_1=Data[0]['material_selection']
	oprn_start_execution_date_1=Data[0]['oprn_start_execution_date']
	oprn_start_execution_time_1=Data[0]['oprn_start_execution_time']
	oprn_end_execution_date_1=Data[0]['oprn_end_execution_date']
	oprn_end_execution_time_1=Data[0]['oprn_end_execution_time']
	flag_1=Data[0]['flag']
	mov_type_1=Data[0]['mov_type']
	# Get new Unique ID from tag
	uid_1=system.tag.readAsync('[B_IMS]REST_API/UID_Operation').value
	uid_1=uid_1+1
	system.tag.write('[B_IMS]REST_API/UID_Operation', uid_1)
	# Insert into goodmov table with new uid_1
	query2='''
			INSERT INTO [dbo].[initialsc]
			           ([oprn]
			           ,[prod_order]
			           ,[yield]
			           ,[long_text]
			           ,[oprn_start_execution_date]
			           ,[oprn_start_execution_time]
			           ,[oprn_end_execution_date]
			           ,[oprn_end_execution_time]
			           ,[uid]
			           ,[mov_type])
			     VALUES
			           (?,trim(?),?,trim(?),trim(?),?,trim(?),?,?,trim(?))
			'''
			
	args=[oprn_1,prod_order_1,yield_1,long_text_1,oprn_start_execution_date_1,oprn_start_execution_time_1,oprn_end_execution_date_1,oprn_end_execution_time_1,uid_1,mov_type_1]		
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')			
	
										