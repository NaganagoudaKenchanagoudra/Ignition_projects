# Function to call for IN Operation exists
def post_SAP_IN(ID,OPRN,PONO,MC,MD,MS,QTY,BATCH,SL,F,MT):
	template = {
			    "row": {
			        "id": "",
			        "oprn": "",
			        "prod_order": "",
			        "material_code": "",
			        "material_description": "",
			        "material_selection": "",
			        "qty": "",
			        "qty_uom": "KG",
			        "batch": "",
			        "valuation_type": "",
			        "storage_loc": "",
			        "flag": "",
			        "message_type": "",
			        "remarks": "",
			        "mov_type":""
			    }
			}
	# Update the values of specific keys as needed
	template["row"]["id"] = ID
	template["row"]["oprn"] = OPRN		
	template["row"]["prod_order"] = PONO
	template["row"]["material_code"] = MC
	template["row"]["material_description"] = MD
	template["row"]["material_selection"] = MS
	template["row"]["qty"] = QTY
	template["row"]["batch"] = BATCH
	template["row"]["storage_loc"] = SL		
	template["row"]["flag"] = F
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
				
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	payload=str(jsonParams)
	print payload
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementItem/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL1_MaterialEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value
	try:
		postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=300000,readTimeout =300000,bypassCertValidation=True)
	except:
		postReturn={
		    "id": ID,
		    "message_type": "E",
		    "remarks": "No response from SAP"
		}
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)	
	
	#	Check if the Empty response from SAP
	if RESPONSE is None:
		# Make a copy in error log table
		API.Error_Goodmov.move_to_Egoodmov('Empty response from SAP',payload)			
		# regenrate the API call with new Unique ID
		API.API_Material_Entry.Regenrate_API()
		# Delete the API transaction
		API.API_Material_Entry.update_tempgodmov_table(ID)
		# Record the log data in API Log
		STATUS="R"
		API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,STATUS,"Collected empty response from SAP",jsonParams)
		
	
	else:
		# Condition to save and acknowledge	
		#Update the logtable
		API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,RESPONSE["message_type"],RESPONSE['remarks'],jsonParams)
					 	
		# If error delete the entry in MF&HF table	
		if str(RESPONSE["message_type"])=='E':	
			# Make a copy in error log table
			API.Error_Goodmov.move_to_Egoodmov(RESPONSE['remarks'],payload)		
			
			#Delete the entry in MF&HF operation	
			API.API_Material_Entry.delete_entry_MFHF(ID)	
			
			if MT is None:
				#Delete the entry in MF&HF operation	
				API.API_Material_Entry.delete_entry_MFHF(int(RESPONSE['id']))	
			else:
				pass	
			API.API_Material_Entry.delete_godmov_and_tempgodmov(int(RESPONSE['id']))
			print 'API Failed'	
		else:
			pass 	
			
		#Update the tempgodmov table
		API.API_Material_Entry.update_tempgodmov_table(RESPONSE['id'])
			
	# Unblock the API que	
	system.tag.write('[B_IMS]REST_API/Q1', False)
	# Update NA PO No to Tag
	system.tag.write('[B_IMS]REST_API/POQ1','NA1')	
	return 	RESPONSE

# Function to call if OUT type exists				
def post_SAP_OUT(ID,OPRN,PONO,MC,MD,MS,QTY,VT,SL,F,MT):
	template = {
			    "row": {
			        "id": "",
			        "oprn": "",
			        "prod_order": "",
			        "material_code": "",
			        "material_description": "",
			        "material_selection": "",
			        "qty": "",
			        "qty_uom": "KG",
			        "batch": "",
			        "valuation_type": "",
			        "storage_loc": "",
			        "flag": "",
			        "message_type": "",
			        "remarks": "",
			        "mov_type":""
			    }
			}
	# Update the values of specific keys as needed
	template["row"]["id"] = ID
	template["row"]["oprn"] = OPRN		
	template["row"]["prod_order"] = PONO
	template["row"]["material_code"] = MC
	template["row"]["material_description"] = MD
	template["row"]["material_selection"] = MS
	template["row"]["qty"] = QTY
	template["row"]["valuation_type"] = VT
	template["row"]["storage_loc"] = SL		
	template["row"]["flag"] = F
	# Check if OPRN 40 then batch as 'INHSCRDF01'	
	if OPRN==40:
		template["row"]["batch"] = 'INHSCRDF01'
	else:
		pass	
	# Check if MT is Empty
	if MT is None:
		template["row"]["mov_type"] = ""
	else:
		template["row"]["mov_type"] = str(MT)
		
	# encode dictionary to JSON
	jsonParams = system.util.jsonEncode(template)
	print jsonParams
	payload=str(jsonParams)
	# post to SAP
#	url='http://jalpodev.jindalaluminium.com:50000/RESTAdapter/CIMSMovementItem/'
	url=system.tag.read('[B_IMS]REST_API/REST_Tags/URL1_MaterialEntry').value
	Uname=system.tag.read('[B_IMS]REST_API/REST_Tags/UName').value
	Pw=system.tag.read('[B_IMS]REST_API/REST_Tags/UPassword').value	
	try:
		postReturn =system.net.httpPost(url,'application/json',postData =jsonParams,username=Uname,password=Pw,connectTimeout=300000,readTimeout =300000,bypassCertValidation=True)
	except:
		postReturn = {
				    "id": ID,
				    "message_type": "E",
				    "remarks": "No response from SAP"
				}
	#Convert received data to dictonary
	RESPONSE=system.util.jsonDecode(postReturn)
	
	#	Check if the Empty response from SAP
	if RESPONSE is None:
		# Make a copy in error log table
		API.Error_Goodmov.move_to_Egoodmov('Empty response from SAP',payload)		
		# regenrate the API call with new Unique ID
		API.API_Material_Entry.Regenrate_API()
		# Delete the API transaction
		API.API_Material_Entry.update_tempgodmov_table(ID)
		# Record the log data in API Log
		STATUS="R"
		API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,STATUS,"Collected empty response from SAP",jsonParams)
	
	else:		
		# Condition to save and acknowledge	
		#Update the logtable
		API.API_Material_Entry.update_log_table(ID,OPRN,PONO,MC,MS,QTY,'BATCH',RESPONSE['message_type'],RESPONSE['remarks'],jsonParams)
				
		# If error delete the entry in MF&HF table	
		if str(RESPONSE['message_type'])=='E':		
			# Make a copy in error log table
			API.Error_Goodmov.move_to_Egoodmov(RESPONSE['remarks'],payload)
			
			if MT is None:
				#Delete the entry in MF&HF operation	
				API.API_Material_Entry.delete_entry_MFHF(int(RESPONSE['id']))	
			else:
				pass	
			API.API_Material_Entry.delete_godmov_and_tempgodmov(int(RESPONSE['id']))
			print 'API Failed'	
		else:
			pass			
		#Update the tempgodmov table
		API.API_Material_Entry.update_tempgodmov_table(RESPONSE['id'])
		
	# Unblock the API que	
	system.tag.write('[B_IMS]REST_API/Q1', False)
	# Update NA PO No to Tag
	system.tag.write('[B_IMS]REST_API/POQ1','NA1')	
	
			
# Insert the API logs into the API LOG table in CIMS2 DB
def update_log_table(ID,OPRN,PONO,MC,MS,QTY,BATCH,STATUS,MESSAGE,PAYLOAD):
	query='''
			INSERT INTO [dbo].[API_logs]
			           ([uid]
			           ,[oprn]
			           ,[pono]
			           ,[material_code]
			           ,[material_selection]
			           ,[batch]
			           ,[qty]
			           ,[qty_uom]
			           ,[status]
			           ,[message]
			           ,[payload])
			     VALUES
			           (?,?,?,?,?,?,?,'KG',?,?,?)
			'''
	args=[int(ID),int(OPRN),str(PONO),str(MC),str(MS),str(BATCH),float(QTY),str(STATUS),str(MESSAGE),str(PAYLOAD)]	
	return system.db.runPrepUpdate(query, args, 'CIMS2')	

# Update the Tempgod table entry using id and flag
def update_tempgodmov_table(ID):
	query='''
			UPDATE [dbo].[tempgoodmov]
			   SET [flag] = 1
			 WHERE [uid]= ?
			'''	
	args=[int(ID)]	
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')		
	
# Delete the entry in MF&HF operation
def delete_entry_MFHF(ID):	
	query='''
			DELETE FROM [dbo].[mes_MF&HF_operation]
			      WHERE [uid]=?
			'''
	args=[int(ID)]
	return system.db.runPrepUpdate(query, args, 'CIMS2')		
	
# Check the tempGodMov table and call the function POST method to SAP
def temp_GodMov_que_check():	
	try:
		query='''
				SELECT top (1) [oprn]
				      ,trim([prod_order]) as prod_order
				      ,trim([material_code]) as material_code
				      ,trim([material_description]) as material_description
				      ,trim([material_selection]) as material_selection
				      ,trim([batch]) as batch
				      ,[qty]
				      ,trim([qty_uom]) as qty_uom
				      ,trim([valuation_type]) as valuation_type
				      ,trim([storage_loc]) as storage_loc
				      ,[flag]
				      ,[uid]
				      ,[mov_type]
				  FROM [INBOUNDCIMS].[dbo].[tempgoodmov]
				  where flag=0 and oprn is not null
				'''	
		args=[]
		DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
		
		print DATASET[0]['material_selection']	
		QTY = DATASET[0]['qty']	
		QTY = "{:.3f}".format(QTY)	
		print QTY
		print DATASET[0]['qty']
		# Call the function based on the Material_selection type
		if 	DATASET[0]['material_selection']=='IN':		
			# Block tag for holding API
			system.tag.write('[B_IMS]REST_API/Q1', True)	
			# Update PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ1',DATASET[0]['prod_order'])				
#			return API.API_Material_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],DATASET[0]['qty'],DATASET[0]['batch'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])
			return API.API_Material_Entry.post_SAP_IN(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],QTY,DATASET[0]['batch'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])
		elif DATASET[0]['material_selection']=='OUT':				
			# Block tag for holding API
			system.tag.write('[B_IMS]REST_API/Q1', True)
			# Update PO No to Tag
			system.tag.write('[B_IMS]REST_API/POQ1',DATASET[0]['prod_order'])				
#			return API.API_Material_Entry.post_SAP_OUT(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],DATASET[0]['qty'],DATASET[0]['valuation_type'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])		
			return API.API_Material_Entry.post_SAP_OUT(DATASET[0]['uid'],DATASET[0]['oprn'],DATASET[0]['prod_order'],DATASET[0]['material_code'],DATASET[0]['material_description'],DATASET[0]['material_selection'],QTY,DATASET[0]['valuation_type'],DATASET[0]['storage_loc'],DATASET[0]['flag'],DATASET[0]['mov_type'])		
	except:
		system.tag.write('[B_IMS]REST_API/Q1', False)	
		# Update NA PO No to Tag
		system.tag.write('[B_IMS]REST_API/POQ1','NA1')											
# Delete the entry in godMov and temgodmov using UID	
def delete_godmov_and_tempgodmov(uid):
	query='''
			delete INBOUNDCIMS.dbo.goodmov
			where uid=?
			'''		 
	system.db.runPrepUpdate(query, [uid], 'CIMS_SAP_IN')
	query1='''
			delete INBOUNDCIMS.dbo.tempgoodmov
			where uid=?
			'''	
	try:
		system.db.runPrepUpdate(query1, [uid], 'CIMS_SAP_IN')
	except:
		pass		
		
# Regenerate API in que
def Regenrate_API():
	# get existing templog from db table
	query='''
			SELECT TOP (1) [oprn]
			      ,trim([prod_order]) as prod_order
			      ,trim([material_code]) as material_code
			      ,trim([material_description]) as material_description
			      ,trim([material_selection]) as material_selection
			      ,trim([batch]) as batch
			      ,[qty]
			      ,trim([qty_uom]) as qty_uom
			      ,trim([valuation_type]) as valuation_type
			      ,trim([storage_loc]) as storage_loc
			      ,[flag]
			      ,trim([mov_type]) as mov_type
			  FROM [INBOUNDCIMS].[dbo].[tempgoodmov]
			'''
	Data=system.db.runPrepQuery(query, [], 'CIMS_SAP_IN')
	prod_order_1=Data[0]['prod_order']
	material_code_1=Data[0]['material_code']
	material_description_1=Data[0]['material_description']
	material_selection_1=Data[0]['material_selection']
	batch_1=Data[0]['batch']
	qty_1=Data[0]['qty']
	qty_uom_1=Data[0]['qty_uom']
	valuation_type_1=Data[0]['valuation_type']
	storage_loc_1=Data[0]['storage_loc']
	flag_1=Data[0]['flag']
	mov_type_1=Data[0]['mov_type']
	# Get new Unique ID from tag
	uid_1=system.tag.readAsync('[B_IMS]REST_API/UID_MaterialEntry').value
	uid_1=uid_1+1
	system.tag.write('[B_IMS]REST_API/UID_MaterialEntry', uid_1)
	# Insert into goodmov table with new uid_1
	query2='''
			INSERT INTO [dbo].[goodmov]
			           ([oprn]
			           ,[prod_order]
			           ,[material_code]
			           ,[material_description]
			           ,[material_selection]
			           ,[batch]
			           ,[qty]
			           ,[qty_uom]
			           ,[valuation_type]
			           ,[storage_loc]
			           ,[uid]
			           ,[mov_type])
			     VALUES
			           (?,?,?,?,?,?,?,?,?,?,?,?)
			'''
			
	args=[oprn_1,prod_order_1,material_code_1,material_description_1,material_selection_1,batch_1,qty_1,qty_uom_1,valuation_type_1,storage_loc_1,uid_1,mov_type_1]		
	return system.db.runPrepUpdate(query, args, 'CIMS_SAP_IN')			