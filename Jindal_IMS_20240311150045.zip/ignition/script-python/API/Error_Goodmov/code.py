def move_to_Egoodmov(msg,payload):
	# get existing templog from db table
	query='''
		SELECT top (1) [oprn]
		      ,trim([prod_order]) as prod_order
		      ,trim([material_code]) as material_code
		      ,trim([material_description]) as material_description
		      ,trim([material_selection]) as material_selection
		      ,trim([batch]) as batch
		      ,[qty]
		      ,trim([qty_uom]) as qty_uom
		      ,trim([valuation_type]) as valuation_type
		      ,trim([storage_loc]) as storage_loc
		      ,[flag]
		      ,[uid]
		      ,trim([mov_type]) as mov_type
		  FROM [INBOUNDCIMS].[dbo].[tempgoodmov]
		  where flag=0 and oprn is not null
					'''	
	args=[]
	DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
	prod_order_1=DATASET[0]['prod_order']
	material_code_1=DATASET[0]['material_code']
	material_description_1=DATASET[0]['material_description']
	material_selection_1=DATASET[0]['material_selection']
	batch_1=DATASET[0]['batch']
	qty_1=DATASET[0]['qty']
	qty_uom_1=DATASET[0]['qty_uom']
	valuation_type_1=DATASET[0]['valuation_type']
	storage_loc_1=DATASET[0]['storage_loc']
	mov_type_1=DATASET[0]['mov_type']
	flag_1=DATASET[0]['flag']
	oprn_1=DATASET[0]['oprn']
	o_uid=DATASET[0]['uid']
	P=str(payload)
	# Condition to see if Cancellation
	if 	mov_type_1 is None:			
		# Get current UID and Increment	
		uid_1=system.tag.read('[B_IMS]REST_API/UID_MaterialEntry').value
		uid_1=uid_1+1
		system.tag.write('[B_IMS]REST_API/UID_MaterialEntry', uid_1)
	else:
		# Use same ID for cancelling the entry
		uid_1=DATASET[0]['uid']	
	MSG=msg
	# Insert into EGoodMovtable with new uid_1
	query2='''			
		INSERT INTO [dbo].[Egoodmov]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[batch]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc]
		           ,[uid]
		           ,[mov_type]
		           ,[msg]
		           ,[o_uid]
		           ,[payload])
		     VALUES
		           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,trim(?),trim(?),trim(?),?,trim(?),trim(?),?,trim(?))
			'''
	args=[oprn_1,prod_order_1,material_code_1,material_description_1,material_selection_1,batch_1,qty_1,qty_uom_1,valuation_type_1,storage_loc_1,uid_1,mov_type_1,MSG,o_uid,P]		
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')	
	
	
def Resend_E_API(uid):
	# Collect data from Elog table	
	query='''
		SELECT [oprn]
		      ,trim([prod_order]) as prod_order
		      ,trim([material_code]) as material_code
		      ,trim([material_description]) as material_description
		      ,trim([material_selection]) as material_selection
		      ,trim([batch]) as batch
		      ,[qty]
		      ,trim([qty_uom]) as qty_uom
		      ,trim([valuation_type]) as valuation_type
		      ,trim([storage_loc]) as storage_loc
		      ,[flag]
		      ,[uid]
		      ,trim([mov_type]) as mov_type
		  FROM [INBOUNDCIMS].[dbo].[Egoodmov]
		  where uid=?
					'''	
	args=[uid]
	DATASET=system.db.runPrepQuery(query, args, 'CIMS_SAP_IN')
	prod_order_1=DATASET[0]['prod_order']
	material_code_1=DATASET[0]['material_code']
	material_description_1=DATASET[0]['material_description']
	material_selection_1=DATASET[0]['material_selection']
	batch_1=DATASET[0]['batch']
	qty_1=DATASET[0]['qty']
	qty_uom_1=DATASET[0]['qty_uom']
	valuation_type_1=DATASET[0]['valuation_type']
	storage_loc_1=DATASET[0]['storage_loc']
	mov_type_1=DATASET[0]['mov_type']
	flag_1=DATASET[0]['flag']
	oprn_1=DATASET[0]['oprn']
	uid_1=DATASET[0]['uid']
	
	#Insert entry into MF&HF table
	# Collect material selection for MF&HF opertaion
	q3='''select trim([material_sel]) as material_sel FROM [CIMS].[dbo].[material_details]
		  where [Material_code]=?'''
	a3=[material_code_1]	  
	d3=system.db.runPrepQuery(q3, a3, 'CIMS2')
	MFHF_MS=d3[0][0]
	# Insert query for MF&HF Operation
	q4='''INSERT INTO [dbo].[mes_MF&HF_operation]
	           ([oprn]
	           ,[prod_order]
	           ,[material_code]
	           ,[material_description]
	           ,[material_selection]
	           ,[batch]
	           ,[qty]
	           ,[qty_uom]
	           ,[valuation_type]
	           ,[storage_loc]
	           ,[uid])
	     VALUES
	           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,'KG',trim(?),trim(?),?)'''	
	a4=[oprn_1,prod_order_1,material_code_1,material_description_1,MFHF_MS,batch_1,qty_1,valuation_type_1,storage_loc_1,uid_1]      
	system.db.runPrepUpdate(q4, a4, 'CIMS2')     
		
	#Update the entry in EGoodMov table using UID
	q1='''update [INBOUNDCIMS].[dbo].[Egoodmov]
			set flag=1
			where uid=?'''
	a1=[uid_1]
	system.db.runPrepUpdate(q1, a1, 'CIMS_SAP_IN')		
	
	# Insert new entry in logmov table
	query2='''			
		INSERT INTO [dbo].[goodmov]
		           ([oprn]
		           ,[prod_order]
		           ,[material_code]
		           ,[material_description]
		           ,[material_selection]
		           ,[batch]
		           ,[qty]
		           ,[qty_uom]
		           ,[valuation_type]
		           ,[storage_loc]
		           ,[uid]
		           ,[mov_type])
		     VALUES
		           (?,trim(?),trim(?),trim(?),trim(?),trim(?),?,trim(?),trim(?),trim(?),?,trim(?))
			'''
	args=[oprn_1,prod_order_1,material_code_1,material_description_1,material_selection_1,batch_1,qty_1,qty_uom_1,valuation_type_1,storage_loc_1,uid_1,mov_type_1]		
	return system.db.runPrepUpdate(query2, args, 'CIMS_SAP_IN')	
	
	
																			