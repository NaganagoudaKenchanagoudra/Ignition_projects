def doGet(request, session):
	return {'html': '<html><body>Hello World</body></html>'}requestsessionsession