SELECT
    DISTINCT o.[production_order] as ProductionOrder
    ,m.[Machine] as Machine
    ,o.[sfg_code] as SfgCode
    ,o.[planned_order_qty] as PlannedOrderQty
    ,o.[standard_alloy] as StandardAlloy
    ,o.[internal_alloy] as InternalAlloy
    ,o.[log_dia] as LogDia
    ,o.[log_length] as LogLength
    ,o.[release_date] as ReleaseDate
	,m.[Press] as Press
	,m.[Status] as Status
	,m.[Date_and_time] as DateandTime
	,m.[No_of_logs] as NoOfLogs
	,m.[No_of_logs_engraved] as NoOfLogsEngraved
	,1 as ActualWeight
	,m.[Casting_block] as CastingBlock
	,m.[Aluminum_chip_boring] as AluminiumChipBoring
	,m.[Log_end_cutting_discard] as LogEndCuttingDiscard
	,m.[Dross] as Dross
	,m.[Percentage_melt_loss] as MeltingLossPercent
	,(ISNULL(melt.[Yield], 0 ) + ISNULL(hold.[Yield], 0 )) as Yield
	,melt.[Melting_Remark] as MeltingRemarks
	,hold.[Holding_Remark] as HoldingRemarks
	,castOpr.[Casting_Remark] as CastingRemarks
FROM [dbo].[mes_orders] o
LEFT JOIN [dbo].[mes_status] s 
    ON o.[production_order] = s.[mes_po]
    
LEFT JOIN [dbo].[mes_main] m
    ON o.[production_order] = m.[PO]
    
LEFT JOIN [dbo].[mes_melting] melt
    ON o.[production_order] = melt.[PO]
    
LEFT JOIN [dbo].[mes_holding] hold
    ON o.[production_order] = hold.[PO]
    
LEFT JOIN [dbo].[mes_casting] castOpr
    ON o.[production_order] = castOpr.[PO]
    
WHERE m.[PO] = o.[production_order] AND
o.[release_date] >= DATEADD(day, -365, getdate());