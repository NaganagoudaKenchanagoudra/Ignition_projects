SELECT trim([STO_PO]) as STO_PO,
	       [Quantity]
	      ,trim([From]) as 'From'
		  ,trim([To]) as 'To'
	      ,[PO_Release_date]
	      ,[No_of_Logs]
	      ,trim([Status]) as 'Status'
	  FROM [CIMS].[dbo].[SAP_Dispatch]
	  Where [PO_Release_date]>=:from and [PO_Release_date]<=:to