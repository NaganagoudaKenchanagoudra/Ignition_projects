USE [Vision_Test]

DECLARE @RC int
DECLARE @p_Name varchar(255)
DECLARE @p_Id int

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[InsertAndSelect] 
    :Name 
  , :Id 
