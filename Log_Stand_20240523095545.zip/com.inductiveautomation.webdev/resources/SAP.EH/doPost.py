def doPost(request, session):
	# take in some JSON data and print it
	# get the incoming parameters
	data = request['postData']
#	data=data['row']
	# Store values in variables
	prod_order = data["prod_order"]
	log_batch_no = data["log_batch_no"]
	sfg_code = data["sfg_code"]
	scrap = data["scrap"]
	yield_value = data["yield"]
	qty_uom = data["qty_uom"]
	homog_start_date = data["homog_start_date"]
	homog_start_time = data["homog_start_time"]
	homog_end_date = data["homog_end_date"]
	homog_end_time = data["homog_end_time"]
	flag = data["flag"]
	oprn = data["oprn"]
	uid = data["uid"]

	
#	Check wheter entry available wrt srno
	SelectQuery='''
	  select *   FROM [OUTBOUNDCIMS].[dbo].[APISAPOrders]
	  	  where id=?
	'''
	SelectArgs=[int(ID)]
	SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'SAPOUTBOUND')
	
	if len(SelectData)>=1:
		RETURN= 'Data available in table'
	else:
		# Insert into table
		InsertQueryquery='''
		INSERT INTO [dbo].[APISAPOrders]
		           ([id]
		           ,[remarks]
		           ,[prod_order]
		           ,[material_code]
		           ,[planned_order_qty]
		           ,[order_qty_unit]
		           ,[standard_alloy]
		           ,[internal_alloy]
		           ,[log_dia]
		           ,[log_dia_unit]
		           ,[log_length]
		           ,[log_length_unit]
		           ,[release_date]
		           ,[status])
	     VALUES
	           (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		'''
		InsertArgs=[int(ID),str(remarks),str(prod_order),str(material_code),float(planned_order_qty),str(order_qty_unit),str(standard_alloy),str(internal_alloy),int(log_dia),str(log_dia_unit),int(log_length),str(log_length_unit),str(release_date),str(status)]
		system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'SAPOUTBOUND')
		RETURN='Data added successfully in table'
	
	return {'html': RETURN}