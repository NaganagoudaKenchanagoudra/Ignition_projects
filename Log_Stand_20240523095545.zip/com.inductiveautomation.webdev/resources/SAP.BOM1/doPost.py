def doPost(request, session):
	# take in some JSON data and print it
	# get the incoming parameters
	data = request['postData']
	data=data['row']
	# condition to see if single of multiple data available in Payload
	datatype=type(data)
	if datatype == dict:	
		ID=data['id']
	#	remarks=data['remarks']
		mc=data['material_code']
		batch=data['batch']
		qty=data['quantity']
		quom=data['quantity_uom']
		valtype=data['valuation_type']
		storag_loc=data['storage_loc']
		m_type=data['movement_type']
		m_des=data['material_desc']
		m_sel=data['material_sel']
		m_doc=data['matdoc']
		d_ind=data['dc_ind']
		item=data['item']
		year=data['year']
		date=data['date']
		time=data['time']
	
		
	#	Check wheter entry available wrt srno
		SelectQuery='''
		  select *   FROM [OUTBOUNDCIMS].[dbo].[APISAPBOM]
		  where id=?
		'''
		SelectArgs=[str(ID)]
		SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'SAPOUTBOUND')
		
		#	Teco Status
		if 	len(SelectData)>=1 and 'TECO' in status:
			# Update the API Order table
			PO_TECO.Update(prod_order)	
			RETURN= 'PO Moved to TECO status'
		
		elif len(SelectData)>=1:
			RETURN= 'Data available in table'
				
		else:
			# Insert into table
			InsertQueryquery='''
			INSERT INTO [dbo].[APISAPBOM]
			           ([id]
			           --,[remarks]
			           ,[material_code]
			           ,[batch]
			           ,[quantity]
			           ,[quantity_uom]
			           ,[valuation_type]
			           ,[storage_loc]
			           ,[movement_type]
			           ,[material_desc]
			           ,[material_sel]
			           ,[matdoc]
			           ,[dc_ind]
			           ,[item]
			           ,[year]
			           ,[date]
			           ,[time])
			     VALUES
			           (?,?,?,?,?,?,?,?,?,?,?,?,?,?,TRIM(?),TRIM(?))
			'''
			InsertArgs=[str(ID),str(mc),str(batch),float(qty),str(quom),str(valtype),str(storag_loc),int(m_type),str(m_des),str(m_sel),int(m_doc),str(d_ind),int(item),int(year),str(date),str(time)]
			system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'SAPOUTBOUND')
			RETURN='Data added successfully in table'
	elif datatype == list:
		for i in range (len(data)):
			data1=data[i]
			ID=data1['id']
		#	remarks=data['remarks']
			mc=data1['material_code']
			batch=data1['batch']
			qty=data1['quantity']
			quom=data1['quantity_uom']
			valtype=data1['valuation_type']
			storag_loc=data1['storage_loc']
			m_type=data1['movement_type']
			m_des=data1['material_desc']
			m_sel=data1['material_sel']
			m_doc=data1['matdoc']
			d_ind=data1['dc_ind']
			item=data1['item']
			year=data1['year']
			date=data1['date']
			time=data1['time']			
		#	Check wheter entry available wrt srno
			SelectQuery='''
			  select *   FROM [OUTBOUNDCIMS].[dbo].[APISAPBOM]
			  where id=?
			'''
			SelectArgs=[str(ID)]
			SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'SAPOUTBOUND')
			
			if len(SelectData)>=1:
				RETURN= 'Data available in table'
			else:
				# Insert into table
				InsertQueryquery='''
				INSERT INTO [dbo].[APISAPBOM]
				           ([id]
				           --,[remarks]
				           ,[material_code]
				           ,[batch]
				           ,[quantity]
				           ,[quantity_uom]
				           ,[valuation_type]
				           ,[storage_loc]
				           ,[movement_type]
				           ,[material_desc]
				           ,[material_sel]
				           ,[matdoc]
				           ,[dc_ind]
				           ,[item]
				           ,[year]
				           ,[date]
				           ,[time])
				     VALUES
				           (?,?,?,?,?,?,?,?,?,?,?,?,?,?,TRIM(?),TRIM(?))
				'''
				InsertArgs=[str(ID),str(mc),str(batch),float(qty),str(quom),str(valtype),str(storag_loc),int(m_type),str(m_des),str(m_sel),int(m_doc),str(d_ind),int(item),int(year),str(date),str(time)]
				system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'SAPOUTBOUND')
			RETURN='Data added successfully in table'		
	
	return {'html': RETURN}