def doPost(request, session):
	# take in some JSON data and print it
	# get the incoming parameters
	data = request['postData']
	ID=data['id']
	error=data['error']
	mc=data['material_code']
	batch=data['batch']
	qty=data['quantity']
	quom=data['quantity_uom']
	valtype=data['valuation_type']
	storag_loc=data['storage_loc']
	m_type=data['movement_type']
	m_des=data['material_desc']
	m_sel=data['material_sel']
	m_doc=data['matdoc']
	d_ind=data['dc_ind']
	item=data['item']
	year=data['year']

	
#	Check wheter entry available wrt srno
	SelectQuery='''
	  select *   FROM [OUTBOUNDCIMS].[dbo].[APISAPBOM]
	  where id=?
	'''
	SelectArgs=[int(ID)]
	SelectData=system.db.runPrepQuery(SelectQuery, SelectArgs, 'SAPOUTBOUND')
	
	RETURN=str(ID)

#	if len(SelectData)>=1:
#		RETURN= 'Data available in table'
#	else:
#		# Insert into table
#		InsertQueryquery='''
#		INSERT INTO [dbo].[APISAPBOM]
#		           ([id]
#		           ,[error]
#		           ,[material_code]
#		           ,[batch]
#		           ,[quantity]
#		           ,[quantity_uom]
#		           ,[valuation_type]
#		           ,[storage_loc]
#		           ,[movement_type]
#		           ,[material_desc]
#		           ,[material_sel]
#		           ,[matdoc]
#		           ,[dc_ind]
#		           ,[item]
#		           ,[year])
#		     VALUES
#		           (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
#		'''
#		InsertArgs=[int(ID),str(error),str(mc),str(batch),float(qty),str(quom),str(valtype),str(storag_loc),int(m_type),str(m_des),str(m_sel),str(m_doc),str(d_ind),int(item),int(year)]
#		system.db.runPrepUpdate(InsertQueryquery, InsertArgs, 'SAPOUTBOUND')
#		RETURN='Data added successfully in table'
	
	return {'html': RETURN}