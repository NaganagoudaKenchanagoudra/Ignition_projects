  SELECT [PO_No]
      ,[customer_name]
      ,[SO_No]
      ,[PO_release_date]
      ,[section_no]
 	  ,[die_no]
	  ,[std_alloy]
	  ,[temper]
	  ,[no_of_pcs]
      ,[no_of_pcs_tolerance]
      ,[Profile_per_meter_wgt]
      ,[Customer_Segment]
      ,[Priority_Assignment]
FROM [JALOMS].[dbo].[SapFields] 
WHERE po_status = 1 
    AND stage = 'onhold' 
    AND PO_release_date >= DATEADD(day, -7	,CONVERT(date, GETDATE()))
    AND PO_release_date <= CONVERT(date, GETDATE()) 
    order by PO_Release_Date desc; 