  SELECT [PO_No]
      ,[customer_name]
      ,[SO_No] 
      ,[Container_Dia]
      ,[section_no]
      ,[std_alloy] 
      ,[temper]
      ,[order_qty]
      ,[yield_qty]
      ,[balance_PO_qty]
      ,[cut_len]
      ,[cut_len_tolerance]
      ,[order_qty_tolerance]
      ,[Priority_Assignment]
      ,[Marketing_Remarks]
FROM [JALOMS].[dbo].[SapFields] 
WHERE po_status = 1 
    AND stage = 'inprogress' 
    AND PO_release_date >= DATEADD(day, -7	,CONVERT(date, GETDATE()))
    AND PO_release_date <= CONVERT(date, GETDATE()) 
    order by PO_Release_Date desc; 